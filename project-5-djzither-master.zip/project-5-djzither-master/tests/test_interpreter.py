# type: ignore
import pytest
from project5.relation import IncompatibleOperandError, Relation
from project5.interpreter import Interpreter
from project5.datalogprogram import DatalogProgram, Predicate, Rule, Parameter
def test_given_empty_relation_when_add_tuple_then_tuple_in_relation():
    # given
    header = ("a", "b", "c")
    relation = Relation(header, set())
    input = ("'1'", "'2'", "'3'")

    # when
    relation.add_tuple(input)

    # then
    assert 1 == len(relation.set_of_tuples)
    assert input in relation.set_of_tuples


def test_given_relation_when_str_then_match_expected():
    # given
    header = ("a", "b", "c")
    set_of_tuples = set([("'1'", "'2'", "'3'"), ("'1'", "'3'", "'5'")])
    relation = Relation(header, set_of_tuples)

    expected = """+-----+-----+-----+
|  a  |  b  |  c  |
+-----+-----+-----+
| '1' | '2' | '3' |
| '1' | '3' | '5' |
+-----+-----+-----+"""

    # when
    answer = str(relation)

    # then
    assert expected == answer


def test_given_relation_and_wrong_size_when_add_tuple_then_exception():
    # given
    relation = Relation(("a", "b", "c"), set())

    # when
    with pytest.raises(IncompatibleOperandError) as exception:
        relation.add_tuple(("1", "2"))

    # then
    assert (
        "Error: ('1', '2') is not compatible with header ['a', 'b', 'c'] in Relation.add_tuple"
        == str(exception.value)
    )


def test_given_relation_when_add_tuple_then_added():
    # given
    relation = Relation(("a", "b", "c"), set())

    # when
    relation.add_tuple(("1", "2", "3"))

    # then
    assert ("1", "2", "3") in relation.set_of_tuples


def test_given_mismatched_header_and_tuple_when_construct_then_exception():
    # given
    header = ("a", "b", "c")
    set_of_tuples = set([("1", "2")])

    # when
    with pytest.raises(IncompatibleOperandError) as exception:
        _ = Relation(header, set_of_tuples)

    # then
    assert (
        "Error: ('1', '2') is not compatible with header ['a', 'b', 'c'] in Relation.add_tuple"
        == str(exception.value)
    )


def test_given_set_that_is_not_over_tuples_when_construct_then_exception():
    # given
    header = "a"
    set_of_tuples = set(["1"])

    # when
    with pytest.raises(IncompatibleOperandError) as exception:
        _ = Relation(header, set_of_tuples)

    # then
    assert (
        "Error: 1 is not type compatible with Relation.RelationTuple in Relation.add_tuple"
        == str(exception.value)
    )


def test_given_set_that_is_tuples_but_not_str_when_construct_then_exception():
    # given
    header = ("a", "b")
    set_of_tuples = set([("1", 2)])

    # when
    with pytest.raises(IncompatibleOperandError) as exception:
        _ = Relation(header, set_of_tuples)

    # then
    assert (
        "Error: ('1', 2) is not type compatible with Relation.RelationTuple in Relation.add_tuple"
        == str(exception.value)
    )


def test_given_mismatched_relations_when_difference_then_exception():
    # given
    left = Relation(("a", "b", "c"), set())
    right = Relation(("a", "b"), set())

    # when
    with pytest.raises(IncompatibleOperandError) as exception:
        left.difference(right)

    # then
    assert (
        "Error: headers ['a', 'b', 'c'] and ['a', 'b'] are not compatible in Relation.difference"
        == str(exception.value)
    )


def test_given_matched_relations_when_difference_then_difference():
    # given
    left = Relation(("a", "b", "c"), set([("1", "2", "3"), ("2", "4", "6")]))
    right = Relation(("a", "b", "c"), set([("2", "4", "6")]))
    expected = Relation(("a", "b", "c"), set([("1", "2", "3")]))

    # when
    answer = left.difference(right)

    # then
    assert expected == answer

# type: ignore
"""Tests for the Datalog interpreter."""


class TestRelation:
    def test_Relation_Intersection(self):
        header = ["A","B"]
        R1 = Relation(header, {("1", "2"), ("2", "3"), ("3", "4")})
        R2 = Relation(header, {("2", "4"), ("2", "3"), ("4", "5")})


        expected_result = Relation(header,{("2", "3")})

        result = R1.intersection(R2)
        assert result == expected_result


    def test_relations_no_shared_headers(self):
        header1 = ["A","B"]
        header2 = ["C","D"]
        R1 = Relation(header1, {("1", "x"), ("2", "y")})
        R2 = Relation(header2, {("z", "w"), ("u", "v")})

        expected_header = ["A", "B", "C", "D"]
        expected_tuples = {("1", "x", "z", "w"), ("1", "x", "u", "v"), ("2", "y", "z", "w"), ("2", "y", "u", "v")}
        expected_result = Relation(expected_header, expected_tuples)
        result = R1.join(R2)
        assert result == expected_result



    def test_relation_same_headers(self):
        # intersection of the sets
        header1 = ["A","B"]
        header2 = ["A","B"]


        R1 = Relation(header1, {("1", "x"), ("2", "y"), ("3","2")})
        R2 = Relation(header2, {("1", "x"), ("2", "y")})

        expected_header = ["A", "B"]
        expected_tuples = {("1","x"), ("2", "y")}
        expected_result = Relation(expected_header, expected_tuples)

        result = R1.join(R2)
        assert result == expected_result

    def test_relation_mixed_headers(self):
        header1 = ["A","B"]
        header2 = ["B","C"]


        R1 = Relation(header1, {("1", "x"), ("2", "y")})
        R2 = Relation(header2, {("x", "z"), ("y", "w")})

        expected_header = ["A", "B", "C"]
        expected_tuples = {("1", "x", "z"), ("2", "y", "w")}
        expected_result = Relation(expected_header, expected_tuples)

        result = R1.join(R2)
        assert result == expected_result

    def test_relation_join_diff_headers(self):
        header1 = ["A", "B"]
        header2 = ["C", "D"]


        R1 = Relation(header1, {("1", "2"), ("3", "4")})
        R2 = Relation(header2, {("x", "y"), ("z", "w")})

        expected_header = ["A", "B", "C","D"]
        expected_tuples = {
        ("1", "2", "x", "y"),
        ("1", "2", "z", "w"),
        ("3", "4", "x", "y"),
        ("3", "4", "z", "w")
        }
        expected_result = Relation(expected_header, expected_tuples)

        result = R1.join(R2)
        assert result == expected_result

    def test_empty_join(self):
        header1 = ["A", "B"]
        header2 = ["B", "C"]

        empty = Relation(header1, set())
        not_empty = Relation(header2, {("1","X"), ("2","Y")})

        result = empty.join(not_empty)

        expected_header = ["A","B","C"]
        assert result.header == expected_header

        assert len(result.set_of_tuples) == 0


    def test_relation_join_type_mismatch_error(self):
        header1 = ["A", "B"]
        header2 = ["B", "C"]

        R1 = Relation(header1, {("1", "x"), ("2", "y")})
        R2 = Relation(header2, {("x", "1"), ("y", "2")})

        with pytest.raises(IncompatibleOperandError):
            result = R1.join(R2)

    def test_project(self):
        header = ["A", "B", "C"]
        R1 = Relation(header, {("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9")})


        project_columns = ["A", "C"]
        expected_header = ["A", "C"]
        expected_tuples = {("1", "3"), ("4", "6"), ("7", "9")}
        expected_result = Relation(expected_header, expected_tuples)

        result = R1.project(project_columns)
        assert result == expected_result

    def test_rename(self):
         header = ["A", "B", "C"]
         R1 = Relation(header, {("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9")})

         expected_header = ["A", "B", "D"]
         expected_tuples = {("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9")}
         expected_result = Relation(expected_header, expected_tuples)

         result = R1.rename(expected_header)
         assert result == expected_result

    def test_select_eq_lit(self):

        header = ["A", "B", "C"]
        tuples = {("1", "2", "3"), ("4", "5", "6"), ("1", "5", "9")}
        R = Relation(header, tuples)


        src_column = "A"
        literal = "1"
        expected_header = ["A", "B", "C"]
        expected_tuples = {("1", "2", "3"), ("1", "5", "9")}
        expected_result = Relation(expected_header, expected_tuples)

        result = R.select_eq_lit(src_column, literal)
        assert result == expected_result, "Failed test where column 'A' equals '1'"

    def test_Relation_union(self):
        header = ["A","B"]
        R1 = Relation(header, {("1", "2"), ("2", "3"), ("3", "4")})
        R2 = Relation(header, {("2", "4"), ("2", "3"), ("4", "5")})


        expected_result = Relation({("1", "2"), ("2", "3"), ("3", "4"), ("2", "4"), ("4", "5")})

        result = R1.union(R2)
        assert result == expected_result

    def test_Relation_union(self):
        header = ["A","B"]
        R1 = Relation(header, {("1", "2"), ("2", "3"), ("3", "4")})
        R2 = Relation(header, {("2", "4"), ("2", "3"), ("4", "5")})


        expected_result = Relation(header,{("1", "2"), ("2", "3"), ("3", "4"), ("2", "4"), ("4", "5")})

        result = R1.union(R2)
        assert result == expected_result

    def test_eval_rules(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)
        interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("4", "3")])
        interpreter.database["g"] = Relation(["c", "d"], [("3", "2")])
        interpreter.database["r"] = Relation(["e", "f"], [("3", "5")])

        rule1 = Rule(head=Predicate("r", [Parameter.id("E"), Parameter.id("F")]), predicates=[Predicate("f", [Parameter.id("E"), Parameter.id("F")])])
        rule2 = Rule(head=Predicate("g", [Parameter.id("C"), Parameter.id("D")]), predicates=[Predicate("f", [Parameter.id("C"), Parameter.id("X")]), Predicate("r", [Parameter.id("X"), Parameter.id("D")])])

        interpreter.datalog.rules = [rule1, rule2]

        passes = 0
        while True:
            changes_detected = False
            for before_rel, rule, updated_relation in interpreter.eval_rules():
                if before_rel.set_of_tuples != updated_relation.set_of_tuples:
                    changes_detected = True
            passes += 1
            if not changes_detected:
                break


        expected_r_tuples = {("1", "2"), ("4", "3"), ("3", "5")}
        expected_g_tuples = {("3", "2"), ("4", "5")}

        actual_r_tuples = set(interpreter.database["r"].set_of_tuples)
        actual_g_tuples = set(interpreter.database["g"].set_of_tuples)

        assert actual_r_tuples == expected_r_tuples, f"Expected {expected_r_tuples}, got {actual_r_tuples}"
        assert actual_g_tuples == expected_g_tuples, f"Expected {expected_g_tuples}, got {actual_g_tuples}"
        assert passes == 2, f"Expected 2 passes to fix point, got {passes}"







    def test_eval_rules_harder(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        # Initializing relations in the database
        interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("4", "3")])
        interpreter.database["g"] = Relation(["c", "d"], [("3", "2")])
        interpreter.database["r"] = Relation(["e", "f"], [("3", "5")])

        # Defining predicates
        pred_f = Predicate("f", ["E", "F"])
        pred_r = Predicate("r", ["E", "F"])
        pred_g = Predicate("g", ["C", "D"])

        # Defining rules
        rule1 = Rule(head=Predicate("r", [Parameter.id("E"), Parameter.id("F")]),
                    predicates=[Predicate("f", [Parameter.id("E"), Parameter.id("F")])])

        rule2 = Rule(head=Predicate("g", [Parameter.id("C"), Parameter.id("D")]),
                    predicates=[Predicate("f", [Parameter.id("C"), Parameter.id("X")]),
                                Predicate("r", [Parameter.id("X"), Parameter.id("D")])])

        # Add rules to the datalog program
        interpreter.datalog.rules = [rule1, rule2]

        # Initialize the expected tuples after evaluation
        expected_r_tuples = {("1", "2"), ("4", "3"), ("3", "5")}
        expected_g_tuples = {("3", "2"), ("4", "5")}

        # Run the evaluation of rules until no changes are detected
        passes = 0
        while True:
            changes_detected = False
            # Iterate through the evaluated rules to apply them
            for before_rel, rule, updated_relation in interpreter.eval_rules():
                if before_rel.set_of_tuples != updated_relation.set_of_tuples:
                    changes_detected = True
            passes += 1
            # Break if no changes were detected in this pass
            if not changes_detected:
                break

        # Get the actual tuples from the database after evaluation
        actual_r_tuples = set(interpreter.database["r"].set_of_tuples)
        actual_g_tuples = set(interpreter.database["g"].set_of_tuples)

        # Assert that the actual tuples match the expected ones
        assert actual_r_tuples == expected_r_tuples, f"Expected {expected_r_tuples}, got {actual_r_tuples}"
        assert actual_g_tuples == expected_g_tuples, f"Expected {expected_g_tuples}, got {actual_g_tuples}"

    def test_rule_evaluation_from_chat_refactored(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        # Initializing relations in the database
        interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("4", "3")])
        interpreter.database["g"] = Relation(["c", "d"], [("3", "2")])
        interpreter.database["r"] = Relation(["e", "f"], [("3", "5")])

        # Defining predicates
        pred_f = Predicate("f", ["E", "F"])
        pred_r = Predicate("r", ["E", "F"])
        pred_g = Predicate("g", ["C", "D"])

        # Defining rules
        rule1 = Rule(head=Predicate("r", [Parameter.id("E"), Parameter.id("F")]),
                    predicates=[Predicate("f", [Parameter.id("E"), Parameter.id("F")])])

        rule2 = Rule(head=Predicate("r", [Parameter.id("X"), Parameter.id("Y")]),
                    predicates=[Predicate("g", [Parameter.id("X"), Parameter.id("R")]),
                                Predicate("f", [Parameter.id("Y"), Parameter.id("S")])])

        rule3 = Rule(head=Predicate("g", [Parameter.id("C"), Parameter.id("D")]),
                    predicates=[Predicate("f", [Parameter.id("C"), Parameter.id("X")]),
                                Predicate("r", [Parameter.id("X"), Parameter.id("D")])])

        # Add rules to the datalog program
        interpreter.datalog.rules = [rule1, rule2, rule3]

        # Initialize the expected tuples after evaluation
        expected_r_tuples = {("1", "2"), ("4", "3"), ("3", "5")}
        expected_g_tuples = {("3", "2"), ("4", "5"), ("4", "1")}
        expected_final_r_tuples = {("1", "2"), ("4", "3"), ("3", "5"), ("4", "1")}

        # Run the evaluation of rules until no changes are detected
        passes = 0

        # Iterate through the evaluated rules to apply them
        for before_rel, rule, updated_relation in interpreter.eval_rules():

            print(f"Applying Rule: {rule}")
            print(f"Before: {before_rel.set_of_tuples}")
            print(f"After: {updated_relation.set_of_tuples}")
            if before_rel.set_of_tuples != updated_relation.set_of_tuples:
                changes_detected = True
        passes += 1
        # Break if no changes were detected in this pass


        # Get the actual tuples from the database after evaluation
        actual_r_tuples = set(interpreter.database["r"].set_of_tuples)
        actual_g_tuples = set(interpreter.database["g"].set_of_tuples)

        # Assert that the actual tuples match the expected ones
        assert actual_r_tuples == expected_final_r_tuples, f"Expected {expected_final_r_tuples}, got {actual_r_tuples}"
        assert actual_g_tuples == expected_g_tuples, f"Expected {expected_g_tuples}, got {actual_g_tuples}"



    # def test_eval_rules_with_header_errors(self):
    #     datalog_program = DatalogProgram()
    #     interpreter = Interpreter(datalog=datalog_program)
    #     interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("4", "3")])
    #     interpreter.database["g"] = Relation(["c", "d"], [("3", "2")])
    #     interpreter.database["r"] = Relation(["e", "f"], [("3", "5")])

    #     rule1 = Rule(head=Predicate("r", ["E", "F"]), predicates=[Predicate("f", ["E", "F"])])
    #     rule2 = Rule(head=Predicate("g", ["C", "D"]), predicates=[Predicate("f", ["C", "X"]), Predicate("r", ["X", "D"])])

    #     interpreter.datalog.rules = [rule1, rule2]

    #     with pytest.raises(ValueError, match="Error: x is not in relation's headers"):
    #         interpreter.eval_rules()

    #     rule3 = Rule(head=Predicate("r", ["A", "B"]), predicates=[Predicate("f", ["A", "B"])])

    #     interpreter.datalog.rules.append(rule3)

    #     with pytest.raises(ValueError, match="Error: a is not in relation's headers"):
    #         interpreter.eval_rules()

    def test_basic_rule_with_one_relation(self):
        # Setup a simple datalog program and interpreter
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        # Simple relation with one predicate
        interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("3", "4")])

        # A basic rule that simply copies the tuples from f to r
        rule1 = Rule(head=Predicate("r", ["A", "B"]), predicates=[Predicate("f", ["A", "B"])])
        interpreter.datalog.rules = [rule1]

        # Evaluate the rule
        interpreter.eval_rules()

        # Debug: Check database content
        print(interpreter.database)  # Log the contents of the database

        # Check that the tuples were copied to relation r
        if "r" in interpreter.database:
            expected_r_tuples = {("1", "2"), ("3", "4")}
            actual_r_tuples = set(interpreter.database["r"].set_of_tuples)
            assert actual_r_tuples == expected_r_tuples, f"Expected {expected_r_tuples}, got {actual_r_tuples}"
        else:
            print("Relation 'r' not found in the database.")  # Log if "r" isn't found


    def test_rule_with_multiple_predicates(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        # Simple relation with one predicate
        interpreter.database["f"] = Relation(["a", "b"], [("1", "2"), ("3", "4")])

        # Rule with multiple predicates (select tuples from f where a = b)
        rule1 = Rule(head=Predicate("r", ["A", "B"]), predicates=[
            Predicate("f", ["A", "B"]),
            Predicate("f", ["B", "A"])
        ])
        interpreter.datalog.rules = [rule1]

        # Evaluate the rule
        interpreter.eval_rules()

        # Expected tuples should only be those where A equals B
        expected_r_tuples = {("1", "1")}
        actual_r_tuples = set(interpreter.database["r"].set_of_tuples)

        # Assert the expected result
        assert actual_r_tuples == expected_r_tuples, f"Expected {expected_r_tuples}, got {actual_r_tuples}"

    def test_rule_dependency_graph(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        rules = [
            Rule(head=Predicate("r", ["E","F"]),
                predicates=[Predicate("f", ["E", "F"])]),  # r0
            Rule(head=Predicate("r", ["X", "Y"]),
                predicates=[Predicate("g", ["X", "R"]), Predicate("f", ["Y", "S"])]),  # r1
            Rule(head=Predicate("g", ["C", "D"]),
                predicates=[Predicate("f", ["C", "X"]), Predicate("r", ["X", "D"])]),  # r2
        ]
        expected_adjacency_list = {
        0: [],    # r0 has no dependencies
        1: [2],   # r1 depends on r0
        2: [0, 1],  # r2 depends on r0 and r1
    }

        interpreter.datalog.rules = rules

        # Evaluate the rule
        actual_adjanency_list = interpreter.get_rule_dependency_graph()

        assert actual_adjanency_list == expected_adjacency_list, f"Expected{expected_adjacency_list}, got {actual_adjanency_list} "


    def test_rule_dependency_graph_reversed(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        rules = [
            Rule(head=Predicate("r", ["E","F"]),
                predicates=[Predicate("f", ["E", "F"])]),  # r0
            Rule(head=Predicate("r", ["X", "Y"]),
                predicates=[Predicate("g", ["X", "R"]), Predicate("f", ["Y", "S"])]),  # r1
            Rule(head=Predicate("g", ["C", "D"]),
                predicates=[Predicate("f", ["C", "X"]), Predicate("r", ["X", "D"])]),  # r2
        ]
        expected_adjacency_list = {
        0: [2],
        1: [2],   # r1 depends on r0
        2: [1],  # r2 depends on r0 and r1
    }

        interpreter.datalog.rules = rules

        # Evaluate the rule
        actual_adjanency_list = interpreter.get_rule_dependency_graph_reversed()

        assert actual_adjanency_list == expected_adjacency_list, f"Expected{expected_adjacency_list}, got {actual_adjanency_list} "


    def test_post_order(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        rules = [
            Rule(head=Predicate("r", ["E","F"]),
                predicates=[Predicate("f", ["E", "F"])]),  # r0
            Rule(head=Predicate("r", ["X", "Y"]),
                predicates=[Predicate("g", ["X", "R"]), Predicate("f", ["Y", "S"])]),  # r1
            Rule(head=Predicate("g", ["C", "D"]),
                predicates=[Predicate("f", ["C", "X"]), Predicate("r", ["X", "D"])]),  # r2
        ]
        expected_post_order_list = [1,2,0]

        interpreter.datalog.rules = rules


        # Evaluate the rule
        actual_post_order_list = interpreter.get_post_order()

        assert actual_post_order_list == expected_post_order_list, f"Expected{expected_post_order_list}, got {actual_post_order_list} "

    def test_sccs(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        rules = [
            Rule(head=Predicate("r", ["E","F"]),
                predicates=[Predicate("f", ["E", "F"])]),  # r0
            Rule(head=Predicate("r", ["X", "Y"]),
                predicates=[Predicate("g", ["X", "R"]), Predicate("f", ["Y", "S"])]),  # r1
            Rule(head=Predicate("g", ["C", "D"]),
                predicates=[Predicate("f", ["C", "X"]), Predicate("r", ["X", "D"])]),  # r2
        ]
        expected_sccs =[{0}, {1, 2}]


        interpreter.datalog.rules = rules

        actual_sccs = interpreter.get_sccs()


        assert actual_sccs == expected_sccs, f"Expected{expected_sccs}, got {actual_sccs} "
    def test_sccs_harder(self):
        datalog_program = DatalogProgram()
        interpreter = Interpreter(datalog=datalog_program)

        rules = [
            Rule(head=Predicate("s1", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s0", ["a", "b", "c", "d", "e"])]),  # r0
            Rule(head=Predicate("s1", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s2", ["b", "c", "d", "e", "a"])]),  # r1
            Rule(head=Predicate("s2", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s1", ["b", "c", "d", "e", "a"])]),  # r2
            Rule(head=Predicate("s1", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s1", ["b", "a", "c", "d", "e"])]),  # r3
            Rule(head=Predicate("s3", ["a", "f", "b", "g", "c", "h", "d", "i"]),
                predicates=[Predicate("s1", ["a", "b", "c", "d", "e"]), Predicate("s2", ["f", "g", "h", "i", "j"])]),  # r4
            Rule(head=Predicate("s5", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s0", ["a", "b", "c", "d", "e"])]),  # r5
            Rule(head=Predicate("s4", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s3", ["a", "b", "z", "y", "c", "d", "e", "i"]), Predicate("s5", ["m", "n", "x", "y", "z"])]),  # r6
            Rule(head=Predicate("s5", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s4", ["a", "b", "c", "d", "e"]), Predicate("s5", ["a", "w", "x", "y", "z"])]),  # r7
            Rule(head=Predicate("s5", ["a", "b", "c", "d", "e"]),
                predicates=[Predicate("s5", ["e", "a", "b", "c", "d"])]),  # r8
        ]

        expected_sccs = [{0}, {1, 2, 3}, {4}, {5}, {6, 7, 8}]

        interpreter.datalog.rules = rules

        actual_sccs = interpreter.get_sccs()

        assert actual_sccs == expected_sccs, f"Expected {expected_sccs}, got {actual_sccs}"

