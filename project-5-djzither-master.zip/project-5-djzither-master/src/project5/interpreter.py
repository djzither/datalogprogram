"""Interpreter for Datalog programs.

Provides an interpreter interface for interpreting Datalog
programs using relational algebra.
"""

from typing import Iterator
from typing import List, Set

from project5.datalogprogram import DatalogProgram, Predicate, Rule
from project5.relation import Relation, IncompatibleOperandError
from project5.reporter import query_report


class Interpreter:
    """Interpreter class for Datalog.

    Defines the interface, and a place for the implementation, for interpreting
    Datalog programs. The interpreter must be implemented using relational algebra,
    so new attributes must be added to track the named relations in the Datalog
    program during the lifetime of the interpreter.

    Attributes:
        datalog (DatalogProgram): The Datalog program to interpret.
    """

    __slots__ = ["datalog", "database"]

    def __init__(self, datalog: DatalogProgram) -> None:
        self.datalog = datalog
        self.database: dict[str, Relation] = {}

    def eval_schemes(self) -> None:
        for scheme in self.datalog.schemes:
            relation_name = scheme.name
            attributes = tuple(param.value for param in scheme.parameters)
            relation = Relation(attributes, set())
            self.database[relation_name] = relation

        """Evaluate the schemes in the Datalog program.

        Create, and store in the interpreter, a relation for each scheme
        in the Datalog program. The _name_ of the scheme must be stored
        separate from the relation since the `Relation` type has no name
        attribute.
        """

    def eval_facts(self) -> None:
        for fact in self.datalog.facts:
            relation_name = fact.name
            values = tuple(param.value for param in fact.parameters)

            if relation_name in self.database:
                self.database[relation_name].add_tuple(values)
            else:
                raise ValueError(f"relation {relation_name} doesn't exist")
        """Evaluate the facts in the Datalog program.

        Create, and store in the appropriate relation belonging to the
        interpreter, a tuple for each fact in the Datalog program.
        """

    def eval_queries(self) -> Iterator[tuple[Predicate, Relation]]:
        """
        Yield each query and resulting relation from evaluation.

        For each query in the Datalog program, evaluate the query to get a
        resulting relation that is the answer to the query, and then yield
        the resulting `(query, relation)` tuple.

        Returns:
            out (tuple[Predicate, Relation]): An iterator to a tuple where the
            first element is the predicate for the query and the second element
            is the relation for the answer.
        """
        for query in self.datalog.queries:
            relation_name = query.name
            params = query.parameters

            if relation_name not in self.database:
                raise ValueError(f"Relation {relation_name} doesn't exist")

            relation = self.database[relation_name]
            selected_relation = relation
            id_indices = []

            param_dict = {}
            for i, param in enumerate(params):
                if param.is_string():
                    selected_relation = selected_relation.select_eq_lit(
                        relation.header[i], param.value
                    )
                else:  # var
                    param_value = param.value
                    if param_value not in param_dict:
                        param_dict[param_value] = relation.header[i]
                        id_indices.append(i)
                    else:
                        selected_relation = selected_relation.select_eq_col(
                            param_dict[param_value], relation.header[i]
                        )

            projected_header = [selected_relation.header[id] for id in id_indices]
            not_repeated_parames = [params[id].value for id in id_indices]

            projected_relation = selected_relation.project(projected_header)
            renamed_relation = projected_relation.rename(not_repeated_parames)

            yield query, renamed_relation

    def eval_rules(self) -> Iterator[tuple[Relation, Rule, Relation]]:
        """Evaluate all rules until no changes are made across relations."""

        print("Initial Database State:")
        for relation_name, relation in self.database.items():
            print(
                f"Relation {relation_name}: {relation.header}, Tuples: {relation.set_of_tuples}"
            )

        passes = 0
        rules_changed = True
        changed_relations = set()

        def align_headers(
            rel_a: Relation, rel_b: Relation
        ) -> tuple[Relation, Relation]:
            """Reorder attributes in relations to align common attributes for joining."""
            all_attrs_a = [attr for attr in rel_a.header]
            all_attrs_b = [attr for attr in rel_b.header]
            ordered_a = rel_a.project(all_attrs_a)
            ordered_b = rel_b.project(all_attrs_b)
            return ordered_a, ordered_b

        while rules_changed:
            rules_changed = False
            changed_relations.clear()

            for rule in self.datalog.rules:
                head_relation_name = rule.head.name
                before_rel = self.database[head_relation_name]

                # print(f"\nEvaluating Rule: {rule}")
                # if head_relation_name in changed_relations:
                #     continue

                intermediate_results = []
                param_dict = {}

                for predicate in rule.predicates:
                    relation = self.database[predicate.name]
                    if predicate.name in changed_relations:
                        selected_relation = self.database[predicate.name]
                    else:
                        selected_relation = relation

                    print(f"  Evaluating Predicate: {predicate}")

                    for i, param in enumerate(predicate.parameters):
                        if param.is_string():  # Lit
                            selected_relation = selected_relation.select_eq_lit(
                                relation.header[i], param.value
                            )
                        else:  # Var
                            param_value = param.value
                            if param_value not in param_dict:
                                param_dict[param_value] = relation.header[i]
                            else:
                                selected_relation = selected_relation.select_eq_col(
                                    param_dict[param_value], relation.header[i]
                                )

                    # Project and rename intermediate relation
                    not_repeated_params = list(param_dict.keys())
                    projected_header = [param_dict[var] for var in not_repeated_params]
                    projected_relation = selected_relation.project(projected_header)
                    renamed_relation = projected_relation.rename(not_repeated_params)

                    print(
                        f"    Intermediate Result: Header={renamed_relation.header}, Tuples={renamed_relation.set_of_tuples}"
                    )
                    intermediate_results.append(renamed_relation)
                    param_dict = {}

                # Combine intermediate results
                if len(intermediate_results) > 1:
                    result_relation = intermediate_results[0]
                    for rel in intermediate_results[1:]:
                        aligned_a, aligned_b = align_headers(result_relation, rel)
                        result_relation = aligned_a.join(aligned_b)
                else:
                    result_relation = intermediate_results[0]

                print(
                    f"  Combined Result: Header={result_relation.header}, Tuples={result_relation.set_of_tuples}"
                )

                # Align result with the rule head
                head_var_caps = [var.value for var in rule.head.parameters]
                normalized_result_header = [col for col in result_relation.header]
                reordered_head_val_pair = []

                for var in head_var_caps:
                    if var in normalized_result_header:
                        index = normalized_result_header.index(var)
                        reordered_head_val_pair.append(result_relation.header[index])
                    else:
                        raise IncompatibleOperandError(
                            f"Error: Variable '{var}' in rule head is not in relation headers: {result_relation.header}. "
                            "Check if the predicates in the rule are defined correctly and the join was successful."
                        )

                # Project and rename final relation
                projected_relation = result_relation.project(reordered_head_val_pair)
                renamed_relation = projected_relation.rename(before_rel.header)

                # Union updated relation with current state
                before_tup = set(before_rel.set_of_tuples)
                updated_relation = before_rel.union(renamed_relation)
                after_tup = set(updated_relation.set_of_tuples)

                self.database[head_relation_name] = updated_relation
                print(f"the new database {self.database[head_relation_name]}")

                if after_tup != before_tup:
                    print(f"  Changes detected in relation {head_relation_name}")
                    rules_changed = True
                    changed_relations.add(head_relation_name)

                yield (before_rel, rule, updated_relation)

            passes += 1
            print(f"Pass {passes} complete.")

        print(f"\nFinished after {passes} passes through the rules.\n")

    def eval_rules_optimized(self) -> Iterator[tuple[Relation, Rule, Relation]]:
        graph = self.get_rule_dependency_graph()
        print("Dependency Graph")
        for rule_index in sorted(graph.keys()):
            successors = sorted(graph[rule_index])  # Sorted list of successor nodes
            print(f"R{rule_index}: {','.join(f'R{succ}' for succ in successors)}")
        print()

        passes = 0
        changed_relations: set[str] = set()
        evaluated_rules: set[int] = set()

        # def align_headers(rel_a: Relation, rel_b: Relation) -> tuple[Relation, Relation]:
        #     """Reorder attributes in relations to align common attributes for joining."""
        #     common_attrs = [attr for attr in rel_a.header if attr in rel_b.header]
        #     aligned_a = rel_a.project(common_attrs)
        #     aligned_b = rel_b.project(common_attrs)
        #     return aligned_a, aligned_b

        sccs = self.get_sccs()

        for scc in sccs:
            print(f"\nProcessing SCC: {scc}")
            local_changed_relations: set[str] = set()
            scc_rules_changed = True

            while scc_rules_changed:
                scc_rules_changed = False
                local_changed_relations.clear()

                for rule_index in sorted(scc):
                    rule = self.datalog.rules[rule_index]
                    head_relation_name = rule.head.name
                    before_rel = self.database[head_relation_name]

                    print(f"\nEvaluating Rule: {rule}")
                    evaluated_rules.add(rule_index)

                    intermediate_results = []
                    param_dict = {}

                    for predicate in rule.predicates:
                        relation = self.database[predicate.name]

                        for i, param in enumerate(predicate.parameters):
                            if param.is_string():
                                relation = relation.select_eq_lit(
                                    relation.header[i], param.value
                                )
                            else:
                                param_value = param.value
                                if param_value not in param_dict:
                                    param_dict[param_value] = relation.header[i]
                                else:
                                    relation = relation.select_eq_col(
                                        param_dict[param_value], relation.header[i]
                                    )

                        projected_relation = relation.project(
                            [param_dict[var] for var in param_dict.keys()]
                        )
                        renamed_relation = projected_relation.rename(
                            list(param_dict.keys())
                        )
                        intermediate_results.append(renamed_relation)
                        param_dict = {}

                    result_relation = intermediate_results[0]
                    for rel in intermediate_results[1:]:
                        # aligned_a, aligned_b = align_headers(result_relation, rel)
                        result_relation = result_relation.join(rel)

                    head_vars = [var.value for var in rule.head.parameters]
                    reordered_header = [
                        result_relation.header[result_relation.header.index(var)]
                        for var in head_vars
                        if var in result_relation.header
                    ]
                    projected_relation = result_relation.project(reordered_header)
                    renamed_relation = projected_relation.rename(before_rel.header)

                    before_tup = set(before_rel.set_of_tuples)
                    updated_relation = before_rel.union(renamed_relation)
                    after_tup = set(updated_relation.set_of_tuples)

                    self.database[head_relation_name] = updated_relation
                    print(f"  Before Tuples for {head_relation_name}: {before_tup}")
                    print(f"  After Tuples for {head_relation_name}: {after_tup}")

                    if after_tup != before_tup:
                        print(f"  Changes detected in relation {head_relation_name}")
                        scc_rules_changed = True
                        local_changed_relations.add(head_relation_name)
                    yield (before_rel, rule, updated_relation)
                    if len(scc) == 1 and list(scc)[0] not in graph[list(scc)[0]]:
                        scc_rules_changed = False

                changed_relations.update(local_changed_relations)

            print(f"End of SCC for pass {passes + 1}")
            passes += 1
            print(f"Pass {passes} complete.")

        print(f"\nFinished after {passes} passes through the rules.\n")

        """Yield each _before_ relation, rule, and _after_ relation from optimized evaluation.

        This function is the same as the `eval_rules` function only it groups rules by strongly
        connected components (SCC) in the dependency graph from the rules in the Datalog
        program. So given the first SCC is with `rule_a` for relation `A`, `rule_b` for
        relation `B`, that takes three evaluations to see no change, and the second SCC with
        `rule_c for relation C that takes two evaluations to see no change, then
        `eval_rules_opt` should:

            yield((A_0, rule_a, A_1))
            yield((B_0, rule_b, B_1))
            yield((A_1, rule_a, A_2))
            yield((B_1, rule_b, B_2))
            yield((A_2, rule_a, A_3))
            yield((B_2, rule_b, B_3))
            yield((C_0, rule_c, C_1))
            yield((C_1, rule_c, C_2))

        Here `A_0` is the initial relation for `A`, `A_1` is the relation after evaluating
        `rule_a` on `A_0` etc. The same for `B` and `C`. The iteration on the first SCC stops
        because `A_2 == A_3` and `B_2 == B_3`. After the iteration for the second SCC starts
        and stops after two iterations when `C_1 == C_2`.

        Returns:
            out (Iterator[tuple[Relation, Rule, Relation]]): An iterator to a tuple where the
                first element is the relation before rule evaluation, the second element is the
                rule associated with the relation, and the third element is the relation resulting
                from the rule evaluation.
        """

    # def get_rule_dependency_graph(self) -> dict[int, list[int]]:
    #     """Return the rule dependency graph.

    #     Computes and returns the graph formed by dependencies between rules.
    #     The graph is used to compute strongly connected components of rules
    #     for optimized rule evaluation.

    #     Rules are zero-indexed so the first rule in the Datalog program is `0`,
    #     the second rules is `1`, etc. A return of `{0 : [0, 1], 1 : [2]}`
    #     means that `0` has edges to `0` and `1`, and `1` has an edge to `2`.

    #     Returns:
    #         out: A map with an entry for each rule and the associated rules connected to it.
    #     """
    #     raise NotImplementedError

    def get_rule_dependency_graph(self) -> dict[str, list[int]]:
        rule_dependency_graph = {}

        for rule_index, rule in enumerate(self.datalog.rules):
            rule_dependency_graph[rule_index] = []

            for predicate in rule.predicates:
                for idx, other_rule in enumerate(self.datalog.rules):
                    if other_rule.head.name == predicate.name:
                        if idx == rule_index:
                            rule_dependency_graph[rule_index].append(rule_index)

                        elif (
                            idx != rule_index
                            and idx not in rule_dependency_graph[rule_index]
                        ):
                            rule_dependency_graph[rule_index].append(idx)
            rule_dependency_graph[rule_index].sort()

        return rule_dependency_graph

    def get_rule_dependency_graph_reversed(self) -> dict[str, list[int]]:
        rule_dependency_graph = {}
        for rule_index in range(len(self.datalog.rules)):
            rule_dependency_graph[rule_index] = []
        for rule_index, rule in enumerate(self.datalog.rules):
            for predicate in rule.predicates:
                for idx, other_rule in enumerate(self.datalog.rules):
                    if other_rule.head.name == predicate.name and idx != rule_index:
                        rule_dependency_graph[idx].append(rule_index)

        return rule_dependency_graph

    def get_post_order(self) -> list[int]:
        reversed_graph = self.get_rule_dependency_graph_reversed()
        visited = {rule_index: False for rule_index in range(len(self.datalog.rules))}
        ## basically this dictional goes trhough all of them that havent been visited and puts them at false
        ## we then will go in to them seeking the bottem and update them 1 by one
        post_order = []

        def dfs(rule_index) -> list[int]:
            visited[rule_index] = True  ##now they have been visited
            for neighbor in sorted(
                reversed_graph[rule_index]
            ):  ##sorted because when there is a choice, it goes up in numarical order
                if not visited[neighbor]:
                    dfs(neighbor)  ##recursively goes from the end and puts the index
            post_order.append(rule_index)

        for rule_index in range(len(self.datalog.rules)):
            if not visited[rule_index]:
                dfs(rule_index)
        return post_order  ##got the post order out

    def get_sccs(self) -> List[Set[int]]:
        ##gets the two graphs reversed
        graph = self.get_rule_dependency_graph()
        reversed_graph = self.get_rule_dependency_graph_reversed()

        ##this is going to recurs do
        def dfs(curr, graph, visited, stack=None, scc=None) -> int:
            visited[curr] = True  # the one I'm on
            if scc is not None:
                scc.append(curr)  # then we can add it
            for neighbor in graph[curr]:
                if not visited[neighbor]:
                    dfs(neighbor, graph, visited, stack, scc)
            if stack is not None:
                stack.append(curr)  # Push node to stack if part of the first pass

        ## haven't done any post order numbers yet
        visited = {rule_index: False for rule_index in range(len(self.datalog.rules))}
        stack = []  ## we are oging to put the post order here
        for rule_index in range(
            len(self.datalog.rules)
        ):  ## we will go through each rule
            if not visited[rule_index]:  ##then go run our algorthmm
                dfs(rule_index, reversed_graph, visited, stack=stack)

        ##going to get SCCS here
        visited = {rule_index: False for rule_index in range(len(self.datalog.rules))}
        sccs = []
        while stack:
            rule_index = stack.pop()  ## going from bottom up
            if not visited[rule_index]:
                scc = []
                dfs(rule_index, graph, visited, scc=scc)
                sccs.append(set(scc))  # Store each SCC as a set of rule indices

        # sorts SCCS because we need consistency
        # sccs = sorted(sccs, key=lambda x: min(x)) ## this is how sorted function works
        return sccs
