"""Turn a input string into a stream of tokens with lexical analysis.

The `lexer(input_string: str)` function is the entry point. It generates a
stream of tokens from the `input_string`.

Examples:

    >>> from project5.lexer import lexer
    >>> input_string = ":\\n  \\n:"
    >>> for i in lexer(input_string):
    ...     print(i)
    ...
    (COLON,":",1)
    (COLON,":",3)
    (EOF,"",3)
"""

from typing import Iterator
from project5.token import Token, TokenType
from project5.fsm import (
    FiniteStateMachine,
    colon_dash,
    Comment,
    Colon,
    Eof,
    WhiteSpace,
    run_fsm,
    Comma,
    right_paren,
    left_paren,
    Rules,
    Schemes,
    period,
    String,
    Queries,
    Facts,
    q_mark,
    ID,
)


def _get_token(input_string: str, fsms: list[FiniteStateMachine]) -> Token:
    best_token = Token.undefined("")
    max_chars_read = 0
    for fsm in fsms:
        num_chars, token = run_fsm(fsm, input_string)
        if num_chars > max_chars_read:
            max_chars_read = num_chars
            best_token = token
    if max_chars_read == 0:
        return Token.undefined(input_string[0])
    return best_token


def _get_new_lines(input_string: str) -> int:
    return input_string.count("\n")


def _is_last_token(token: Token) -> bool:
    if token.token_type == "UNDEFINED" or token.token_type == "EOF":
        return True

    return False


def lexer(input_string: str) -> Iterator[Token]:
    fsms: list[FiniteStateMachine] = [
        Comment(),
        WhiteSpace(),
        colon_dash(),
        Colon(),
        Eof(),
        Schemes(),
        Rules(),
        left_paren(),
        right_paren(),
        Comma(),
        Schemes(),
        Facts(),
        Queries(),
        String(),
        period(),
        q_mark(),
        ID(),
    ]
    hidden: list[TokenType] = ["WHITESPACE", "COMMENT"]
    line_num: int = 1
    token: Token = Token.colon(":")

    while not _is_last_token(token):
        token = _get_token(input_string, fsms)
        token.line_num = line_num
        line_num += _get_new_lines(token.value)
        input_string = input_string.removeprefix(token.value)

        if token.token_type not in hidden:
            yield token
